using BwParser.Core;

namespace BwParser.Bpmn2;

public sealed class BwToBpmnMapper
{
    public BpmnDefinitions Map(BwProcessAst bwAst)
    {
        var process = new BpmnProcess
        {
            Id = NormalizeId(string.IsNullOrWhiteSpace(bwAst.Name) ? "Process_1" : bwAst.Name),
            Name = bwAst.Name,
            IsExecutable = true
        };

        var nodeMap = new Dictionary<string, BpmnFlowNode>(StringComparer.OrdinalIgnoreCase);

        foreach (var bwNode in bwAst.Nodes)
        {
            var mapped = MapNode(bwNode);
            nodeMap[bwNode.Id] = mapped;
            process.FlowNodes.Add(mapped);
        }

        foreach (var t in bwAst.Transitions)
        {
            if (!nodeMap.ContainsKey(t.From) || !nodeMap.ContainsKey(t.To))
                continue;

            var flowId = NormalizeId(string.IsNullOrWhiteSpace(t.Id) ? $"Flow_{t.From}_{t.To}" : t.Id);
            var flow = new BpmnSequenceFlow
            {
                Id = flowId,
                Name = t.Attributes.TryGetValue("name", out var flowName) ? flowName : flowId,
                SourceRef = nodeMap[t.From].Id,
                TargetRef = nodeMap[t.To].Id,
                ConditionExpression = t.ConditionExpression,
                IsDefault = t.IsDefault,
                Extensions = BuildTransitionExtensions(t)
            };

            process.SequenceFlows.Add(flow);
            nodeMap[t.From].Outgoing.Add(flow.Id);
            nodeMap[t.To].Incoming.Add(flow.Id);
        }

        EnsureBoundaryEvents(process);
        ApplyGatewaySemantics(process);

        return new BpmnDefinitions
        {
            Id = $"Definitions_{process.Id}",
            TargetNamespace = bwAst.XmlNamespace ?? "http://example.org/bpmn",
            Processes = new List<BpmnProcess> { process }
        };
    }

    private BpmnFlowNode MapNode(BwNode node)
    {
        return node switch
        {
            BwStarterNode starter => new BpmnStartEvent
            {
                Id = NormalizeId(node.Id),
                Name = node.Name,
                EventDefinitionType = InferEventDefinition(starter.Trigger),
                Extensions = BuildNodeExtensions(node)
            },
            BwSubprocessCallNode subprocess => new BpmnCallActivity
            {
                Id = NormalizeId(node.Id),
                Name = node.Name,
                CalledElement = subprocess.CalledProcess,
                IsSynchronous = subprocess.IsSynchronous,
                Extensions = BuildNodeExtensions(node)
            },
            _ when node.Kind == BwNodeKind.Gateway => new BpmnGateway
            {
                Id = NormalizeId(node.Id),
                Name = node.Name,
                GatewayType = InferGatewayType(node),
                Extensions = BuildNodeExtensions(node)
            },
            _ when node.Kind == BwNodeKind.Event => new BpmnIntermediateCatchEvent
            {
                Id = NormalizeId(node.Id),
                Name = node.Name,
                EventDefinitionType = InferEventDefinition(node),
                Extensions = BuildNodeExtensions(node)
            },
            BwActivityNode activity => new BpmnTask
            {
                Id = NormalizeId(node.Id),
                Name = node.Name,
                TaskType = InferTaskType(activity),
                Extensions = BuildNodeExtensions(node)
            },
            _ => new BpmnTask
            {
                Id = NormalizeId(node.Id),
                Name = node.Name,
                TaskType = "task",
                Extensions = BuildNodeExtensions(node)
            }
        };
    }

    private static void EnsureBoundaryEvents(BpmnProcess process)
    {
        if (!process.FlowNodes.OfType<BpmnStartEvent>().Any())
        {
            var first = process.FlowNodes.FirstOrDefault();
            if (first is not null)
            {
                var start = new BpmnStartEvent { Id = "StartEvent_Auto", Name = "Start" };
                var flow = new BpmnSequenceFlow { Id = "Flow_AutoStart", SourceRef = start.Id, TargetRef = first.Id };
                start.Outgoing.Add(flow.Id);
                first.Incoming.Add(flow.Id);
                process.FlowNodes.Insert(0, start);
                process.SequenceFlows.Insert(0, flow);
            }
        }

        if (process.FlowNodes.OfType<BpmnEndEvent>().Any()) return;

        var terminal = process.FlowNodes.Where(n => n.Outgoing.Count == 0 && n is not BpmnEndEvent).ToList();
        if (terminal.Count == 0) return;

        var end = new BpmnEndEvent { Id = "EndEvent_Auto", Name = "End" };
        process.FlowNodes.Add(end);
        var counter = 1;
        foreach (var node in terminal)
        {
            var f = new BpmnSequenceFlow { Id = $"Flow_AutoEnd_{counter++}", SourceRef = node.Id, TargetRef = end.Id };
            node.Outgoing.Add(f.Id);
            end.Incoming.Add(f.Id);
            process.SequenceFlows.Add(f);
        }
    }

    private static void ApplyGatewaySemantics(BpmnProcess process)
    {
        foreach (var gw in process.FlowNodes.OfType<BpmnGateway>())
        {
            var incoming = gw.Incoming.Count;
            var outgoing = gw.Outgoing.Count;
            gw.GatewayDirection = incoming <= 1 && outgoing > 1 ? "Diverging" : incoming > 1 && outgoing <= 1 ? "Converging" : incoming > 1 && outgoing > 1 ? "Mixed" : "Unspecified";
            var defaultFlow = process.SequenceFlows.FirstOrDefault(f => f.SourceRef == gw.Id && f.IsDefault);
            if (defaultFlow is not null) gw.DefaultFlowId = defaultFlow.Id;
        }
    }

    private static string InferTaskType(BwActivityNode node)
    {
        var type = node.BwType ?? string.Empty;
        var md = node.Metadata;
        if (type.Contains("jdbc", StringComparison.OrdinalIgnoreCase) || !string.IsNullOrWhiteSpace(md.JdbcStatement)) return "serviceTask";
        if (type.Contains("mapper", StringComparison.OrdinalIgnoreCase) || type.Contains("transform", StringComparison.OrdinalIgnoreCase) || !string.IsNullOrWhiteSpace(md.XsltRef)) return "scriptTask";
        if (type.Contains("service", StringComparison.OrdinalIgnoreCase) || type.Contains("callprocess", StringComparison.OrdinalIgnoreCase)) return "serviceTask";
        if (type.Contains("user", StringComparison.OrdinalIgnoreCase) || type.Contains("manual", StringComparison.OrdinalIgnoreCase)) return "userTask";
        return "task";
    }

    private static string InferGatewayType(BwNode node)
    {
        var type = node.BwType ?? string.Empty;
        if (type.Contains("parallel", StringComparison.OrdinalIgnoreCase)) return "parallelGateway";
        if (type.Contains("inclusive", StringComparison.OrdinalIgnoreCase)) return "inclusiveGateway";
        if (type.Contains("event", StringComparison.OrdinalIgnoreCase)) return "eventBasedGateway";
        return "exclusiveGateway";
    }

    private static string? InferEventDefinition(BwStarterTrigger trigger)
    {
        if (!string.IsNullOrWhiteSpace(trigger.Destination)) return "message";
        if (!string.IsNullOrWhiteSpace(trigger.EventName)) return "signal";
        if (string.Equals(trigger.Protocol, "http", StringComparison.OrdinalIgnoreCase)) return "message";
        return null;
    }

    private static string? InferEventDefinition(BwNode node)
    {
        var type = node.BwType ?? string.Empty;
        if (type.Contains("timer", StringComparison.OrdinalIgnoreCase)) return "timer";
        if (type.Contains("message", StringComparison.OrdinalIgnoreCase)) return "message";
        if (type.Contains("signal", StringComparison.OrdinalIgnoreCase)) return "signal";
        if (type.Contains("error", StringComparison.OrdinalIgnoreCase)) return "error";
        return null;
    }

    private static Dictionary<string, string> BuildNodeExtensions(BwNode node)
    {
        var ext = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["bw.kind"] = node.Kind.ToString(),
            ["bw.type"] = node.BwType ?? string.Empty
        };
        foreach (var a in node.Attributes) ext[$"bw.attr.{a.Key}"] = a.Value;
        foreach (var p in node.Inputs.Select((p, i) => (p, i))) ext[$"bw.input.{p.i}.{p.p.Name}"] = p.p.XPath ?? p.p.SchemaRef ?? string.Empty;
        foreach (var p in node.Outputs.Select((p, i) => (p, i))) ext[$"bw.output.{p.i}.{p.p.Name}"] = p.p.XPath ?? p.p.SchemaRef ?? string.Empty;
        if (!string.IsNullOrWhiteSpace(node.Metadata.Endpoint)) ext["bw.meta.endpoint"] = node.Metadata.Endpoint;
        if (!string.IsNullOrWhiteSpace(node.Metadata.Operation)) ext["bw.meta.operation"] = node.Metadata.Operation;
        if (!string.IsNullOrWhiteSpace(node.Metadata.AdapterService)) ext["bw.meta.adapterService"] = node.Metadata.AdapterService;
        if (!string.IsNullOrWhiteSpace(node.Metadata.JdbcStatement)) ext["bw.meta.jdbcStatement"] = node.Metadata.JdbcStatement;
        if (!string.IsNullOrWhiteSpace(node.Metadata.XsltRef)) ext["bw.meta.xsltRef"] = node.Metadata.XsltRef;
        foreach (var xp in node.Metadata.XPaths.Select((x, i) => (x, i))) ext[$"bw.meta.xpath.{xp.i}"] = xp.x;
        foreach (var kv in node.Metadata.RawProperties) ext[$"bw.raw.{kv.Key}"] = kv.Value;
        if (node.Metadata.ConfigurationMessage is not null)
        {
            if (!string.IsNullOrWhiteSpace(node.Metadata.ConfigurationMessage.Name)) ext["bw.config.name"] = node.Metadata.ConfigurationMessage.Name;
            if (!string.IsNullOrWhiteSpace(node.Metadata.ConfigurationMessage.Type)) ext["bw.config.type"] = node.Metadata.ConfigurationMessage.Type;
            if (!string.IsNullOrWhiteSpace(node.Metadata.ConfigurationMessage.Description)) ext["bw.config.description"] = node.Metadata.ConfigurationMessage.Description;
            foreach (var kv in node.Metadata.ConfigurationMessage.Properties) ext[$"bw.config.{kv.Key}"] = kv.Value;
        }
        if (node is BwStarterNode starter)
        {
            if (!string.IsNullOrWhiteSpace(starter.Trigger.Protocol)) ext["bw.trigger.protocol"] = starter.Trigger.Protocol;
            if (!string.IsNullOrWhiteSpace(starter.Trigger.Method)) ext["bw.trigger.method"] = starter.Trigger.Method;
            if (!string.IsNullOrWhiteSpace(starter.Trigger.Path)) ext["bw.trigger.path"] = starter.Trigger.Path;
            if (!string.IsNullOrWhiteSpace(starter.Trigger.Destination)) ext["bw.trigger.destination"] = starter.Trigger.Destination;
            if (!string.IsNullOrWhiteSpace(starter.Trigger.EventName)) ext["bw.trigger.eventName"] = starter.Trigger.EventName;
        }
        if (node is BwSubprocessCallNode call)
        {
            if (!string.IsNullOrWhiteSpace(call.CalledProcess)) ext["bw.calledProcess"] = call.CalledProcess;
            ext["bw.isSynchronous"] = call.IsSynchronous.ToString().ToLowerInvariant();
        }
        return ext;
    }

    private static Dictionary<string, string> BuildTransitionExtensions(BwTransition t)
    {
        var ext = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (!string.IsNullOrWhiteSpace(t.ConditionType)) ext["bw.conditionType"] = t.ConditionType;
        foreach (var a in t.Attributes) ext[$"bw.attr.{a.Key}"] = a.Value;
        return ext;
    }

    private static string NormalizeId(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "Id_" + Guid.NewGuid().ToString("N");
        var chars = value.Select(ch => char.IsLetterOrDigit(ch) || ch == '_' ? ch : '_').ToArray();
        var normalized = new string(chars);
        if (char.IsDigit(normalized[0])) normalized = "_" + normalized;
        return normalized;
    }
}
