using BwParser.Core;

namespace BwParser.Bpmn2;

public sealed class Bpmn2AstBuilder
{
    private readonly BwToBpmnMapper _mapper = new();

    public BpmnDefinitions Build(BwProcessAst bwAst)
        => _mapper.Map(bwAst);
}
