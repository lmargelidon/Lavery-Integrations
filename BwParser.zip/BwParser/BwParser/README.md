# BwParser Full Regenerated

Ce projet regroupe :
- `BwParser.Core` avec support de `ConfigurationMessage` dans l'AST
- `BwParser.Bpmn2` avec mapping BW -> BPMN2
- un serializer XML BPMN2 + BPMNDI compatible affichage Camunda Modeler
- `Program.cs` pour enchaîner BW -> BwAst -> BPMN2

## Intégration

1. Copiez `BwParser.Core/*` dans votre projet core.
2. Ajoutez le projet `BwParser.Bpmn2` à votre solution.
3. Utilisez `Program.cs` comme point d'entrée console.
4. Générez un `.bpmn` avec `BpmnXmlSerializer.Serialize(definitions)`.
