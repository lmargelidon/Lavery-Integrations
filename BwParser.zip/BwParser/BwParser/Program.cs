using System.Text.Json;
using BwParser.Core;
using BwParser.Bpmn2;

var inputPath = args.Length > 0 ? args[0] : "./Test.bw";
var astJsonPath = args.Length > 1 ? args[1] : "./output.bwast.json";
var bpmnPath = args.Length > 2 ? args[2] : "./output.bpmn";

if (!File.Exists(inputPath))
{
    Console.Error.WriteLine($"File not found: {inputPath}");
    return 2;
}

try
{
    var reader = new BwXmlReader();
    var raw = reader.Read(inputPath);

    var bwAstBuilder = new BwAstBuilder();
    var bwAst = bwAstBuilder.Build(raw);
    var graph = bwAstBuilder.BuildGraph(bwAst);

    var bwAstPayload = new
    {
        bwAst.Name,
        bwAst.XmlNamespace,
        Nodes = bwAst.Nodes.Select(n => new
        {
            n.Id,
            n.Name,
            Kind = n.Kind.ToString(),
            n.BwType,
            n.Attributes,
            n.Inputs,
            n.Outputs,
            n.Metadata,
            Trigger = n is BwStarterNode s ? s.Trigger : null,
            CalledProcess = n is BwSubprocessCallNode sp ? sp.CalledProcess : null,
            IsSynchronous = n is BwSubprocessCallNode sp2 ? sp2.IsSynchronous : (bool?)null
        }),
        Transitions = bwAst.Transitions,
        Graph = new
        {
            graph.ProcessName,
            Outgoing = graph.Outgoing.ToDictionary(k => k.Key, v => v.Value.Select(e => e.To).ToList()),
            Incoming = graph.Incoming.ToDictionary(k => k.Key, v => v.Value.Select(e => e.From).ToList())
        }
    };

    var jsonOptions = new JsonSerializerOptions
    {
        WriteIndented = true
    };

    File.WriteAllText(astJsonPath, JsonSerializer.Serialize(bwAstPayload, jsonOptions));

    var mapper = new BwToBpmnMapper();
    var bpmnDefinitions = mapper.Map(bwAst);
    var bpmnXml = BpmnXmlSerializer.Serialize(bpmnDefinitions);
    File.WriteAllText(bpmnPath, bpmnXml);

    var summary = new
    {
        InputFile = Path.GetFullPath(inputPath),
        AstJsonFile = Path.GetFullPath(astJsonPath),
        BpmnFile = Path.GetFullPath(bpmnPath),
        BwProcess = bwAst.Name,
        BwNodeCount = bwAst.Nodes.Count,
        BwTransitionCount = bwAst.Transitions.Count,
        BpmnProcessCount = bpmnDefinitions.Processes.Count,
        BpmnNodeCount = bpmnDefinitions.Processes.SelectMany(p => p.FlowNodes).Count(),
        BpmnSequenceFlowCount = bpmnDefinitions.Processes.SelectMany(p => p.SequenceFlows).Count()
    };

    Console.WriteLine(JsonSerializer.Serialize(summary, jsonOptions));
    return 0;
}
catch (Exception ex)
{
    Console.Error.WriteLine("Conversion failed.");
    Console.Error.WriteLine(ex.ToString());
    return 1;
}
