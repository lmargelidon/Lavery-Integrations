using System.Xml.Linq;

namespace BwParser.Core;

public sealed class BwAstBuilder
{
    public BwProcessAst Build(RawBwProcess raw)
    {
        var nodes = raw.NodeElements.Select(BuildNode).ToList();
        var nodeIds = new HashSet<string>(nodes.Select(n => n.Id), StringComparer.OrdinalIgnoreCase);
        var transitions = raw.TransitionElements.Select(BuildTransition)
            .Where(t => nodeIds.Contains(t.From) && nodeIds.Contains(t.To))
            .ToList();

        return new BwProcessAst
        {
            Name = raw.Name,
            XmlNamespace = raw.XmlNamespace,
            Attributes = raw.Attributes,
            Nodes = nodes,
            Transitions = transitions
        };
    }

    public BwControlFlowGraph BuildGraph(BwProcessAst ast)
    {
        var outgoing = ast.Nodes.ToDictionary(n => n.Id, _ => new List<BwTransition>(), StringComparer.OrdinalIgnoreCase);
        var incoming = ast.Nodes.ToDictionary(n => n.Id, _ => new List<BwTransition>(), StringComparer.OrdinalIgnoreCase);

        foreach (var edge in ast.Transitions)
        {
            if (outgoing.TryGetValue(edge.From, out var outs)) outs.Add(edge);
            if (incoming.TryGetValue(edge.To, out var ins)) ins.Add(edge);
        }

        return new BwControlFlowGraph
        {
            ProcessName = ast.Name,
            Vertices = ast.Nodes,
            Edges = ast.Transitions,
            Outgoing = outgoing,
            Incoming = incoming
        };
    }

    private BwNode BuildNode(RawBwElement raw)
    {
        return raw.ElementName.ToLowerInvariant() switch
        {
            "starter" => BuildStarter(raw.Element),
            "activity" => BuildActivity(raw.Element),
            "subprocess" => BuildSubprocess(raw.Element),
            "gateway" => BuildGateway(raw.Element),
            "startevent" => BuildEvent(raw.Element, true),
            "endevent" => BuildEvent(raw.Element, false),
            _ => new BwActivityNode
            {
                Id = raw.Id,
                Name = raw.Name,
                Kind = BwNodeKind.Unknown,
                Attributes = raw.Element.Attributes().ToDictionary(a => a.Name.LocalName, a => a.Value),
                Metadata = ExtractMetadata(raw.Element)
            }
        };
    }

    private BwStarterNode BuildStarter(XElement el)
    {
        return new BwStarterNode
        {
            Id = ResolveId(el),
            Name = (string?)el.Attribute("name") ?? "Starter",
            Kind = BwNodeKind.Starter,
            BwType = (string?)el.Attribute("type"),
            Attributes = el.Attributes().ToDictionary(a => a.Name.LocalName, a => a.Value),
            Inputs = ExtractPorts(el.Element(el.Name.Namespace + "input"), "in"),
            Outputs = ExtractPorts(el.Element(el.Name.Namespace + "output"), "out"),
            Trigger = new BwStarterTrigger
            {
                Protocol = InferProtocol((string?)el.Attribute("type")),
                Method = FindDescValue(el, "method"),
                Path = FindDescValue(el, "path"),
                Destination = FindDescValue(el, "destination"),
                EventName = FindDescValue(el, "event")
            },
            Metadata = ExtractMetadata(el)
        };
    }

    private BwNode BuildActivity(XElement el)
    {
        var type = (string?)el.Attribute("type");
        if ((type ?? "").Contains("subprocess", StringComparison.OrdinalIgnoreCase))
            return BuildSubprocess(el);

        return new BwActivityNode
        {
            Id = ResolveId(el),
            Name = (string?)el.Attribute("name") ?? "Activity",
            Kind = BwNodeKind.Activity,
            BwType = type,
            Attributes = el.Attributes().ToDictionary(a => a.Name.LocalName, a => a.Value),
            Inputs = ExtractPorts(el.Element(el.Name.Namespace + "input"), "in"),
            Outputs = ExtractPorts(el.Element(el.Name.Namespace + "output"), "out"),
            Metadata = ExtractMetadata(el)
        };
    }

    private BwSubprocessCallNode BuildSubprocess(XElement el)
    {
        return new BwSubprocessCallNode
        {
            Id = ResolveId(el),
            Name = (string?)el.Attribute("name") ?? "Subprocess",
            Kind = BwNodeKind.SubprocessCall,
            BwType = (string?)el.Attribute("type"),
            Attributes = el.Attributes().ToDictionary(a => a.Name.LocalName, a => a.Value),
            Inputs = ExtractPorts(el.Element(el.Name.Namespace + "input"), "in"),
            Outputs = ExtractPorts(el.Element(el.Name.Namespace + "output"), "out"),
            CalledProcess = FindDescValue(el, "processName") ?? FindDescValue(el, "process"),
            IsSynchronous = string.Equals(FindDescValue(el, "spawn"), "false", StringComparison.OrdinalIgnoreCase),
            Metadata = ExtractMetadata(el)
        };
    }

    private BwNode BuildGateway(XElement el) =>
        new BwActivityNode
        {
            Id = ResolveId(el),
            Name = (string?)el.Attribute("name") ?? "Gateway",
            Kind = BwNodeKind.Gateway,
            BwType = (string?)el.Attribute("type"),
            Attributes = el.Attributes().ToDictionary(a => a.Name.LocalName, a => a.Value),
            Inputs = ExtractPorts(el.Element(el.Name.Namespace + "input"), "in"),
            Outputs = ExtractPorts(el.Element(el.Name.Namespace + "output"), "out"),
            Metadata = ExtractMetadata(el)
        };

    private BwNode BuildEvent(XElement el, bool isStart) =>
        new BwActivityNode
        {
            Id = ResolveId(el),
            Name = (string?)el.Attribute("name") ?? (isStart ? "Start" : "End"),
            Kind = BwNodeKind.Event,
            BwType = (string?)el.Attribute("type"),
            Attributes = el.Attributes().ToDictionary(a => a.Name.LocalName, a => a.Value),
            Inputs = ExtractPorts(el.Element(el.Name.Namespace + "input"), "in"),
            Outputs = ExtractPorts(el.Element(el.Name.Namespace + "output"), "out"),
            Metadata = ExtractMetadata(el)
        };

    private BwTransition BuildTransition(RawBwElement raw)
    {
        var el = raw.Element;
        return new BwTransition
        {
            Id = ResolveId(el),
            From = (string?)el.Attribute("from") ?? FindDescValue(el, "from") ?? string.Empty,
            To = (string?)el.Attribute("to") ?? FindDescValue(el, "to") ?? string.Empty,
            ConditionType = (string?)el.Attribute("conditionType") ?? FindDescValue(el, "conditionType"),
            ConditionExpression = (string?)el.Attribute("condition") ?? FindDescValue(el, "condition") ?? FindDescValue(el, "xpath"),
            IsDefault = string.Equals((string?)el.Attribute("isDefault"), "true", StringComparison.OrdinalIgnoreCase),
            Attributes = el.Attributes().ToDictionary(a => a.Name.LocalName, a => a.Value)
        };
    }

    private static List<BwPort> ExtractPorts(XElement? parent, string direction)
    {
        if (parent is null) return new();

        return parent.Elements()
            .Select(x => new BwPort
            {
                Name = x.Name.LocalName,
                SchemaRef = (string?)x.Attribute("schema") ?? (string?)x.Attribute("type"),
                XPath = (string?)x.Attribute("xpath") ?? (string?)x.Attribute("select") ?? NormalizePossibleXPath(x.Value),
                Direction = direction
            })
            .ToList();
    }

    private static BwMetadata ExtractMetadata(XElement el)
    {
        var descendants = el.Descendants().ToList();

        string? find(string local) =>
            descendants.FirstOrDefault(x => x.Name.LocalName.Equals(local, StringComparison.OrdinalIgnoreCase))?.Value?.Trim();

        var raw = descendants
            .GroupBy(x => x.Name.LocalName, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.First().Value, StringComparer.OrdinalIgnoreCase);

        var xpaths = descendants
            .Attributes()
            .Select(a => a.Value)
            .Concat(descendants.Select(d => d.Value))
            .Where(LooksLikeXPath)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        var configurationMessage = ExtractConfigurationMessage(el);

        return new BwMetadata
        {
            Endpoint = find("endpoint") ?? find("url"),
            Operation = find("operation") ?? find("methodName"),
            AdapterService = find("service") ?? find("adapterService"),
            JdbcStatement = find("sql") ?? find("statement") ?? find("query"),
            XsltRef = find("xslt") ?? find("stylesheet") ?? find("xsltFile"),
            XPaths = xpaths,
            RawProperties = raw,
            ConfigurationMessage = configurationMessage
        };
    }

    private static BwConfigurationMessage? ExtractConfigurationMessage(XElement el)
    {
        var config = el
            .Descendants()
            .FirstOrDefault(x => x.Name.LocalName.Equals("ConfigurationMessage", StringComparison.OrdinalIgnoreCase));

        if (config is null)
            return null;

        var props = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        foreach (var attr in config.Attributes())
            props["@" + attr.Name.LocalName] = attr.Value;

        foreach (var child in config.Elements())
        {
            var key = child.Name.LocalName;
            var value = child.HasElements
                ? string.Join(" | ", child.Elements().Select(e => $"{e.Name.LocalName}={e.Value.Trim()}"))
                : child.Value.Trim();

            if (!props.ContainsKey(key))
                props[key] = value;
        }

        return new BwConfigurationMessage
        {
            Name = (string?)config.Attribute("name") ?? FindChildValue(config, "name"),
            Type = (string?)config.Attribute("type") ?? FindChildValue(config, "type"),
            Description = FindChildValue(config, "description"),
            Properties = props
        };
    }

    private static string? FindChildValue(XElement parent, string localName) =>
        parent.Elements().FirstOrDefault(x => x.Name.LocalName.Equals(localName, StringComparison.OrdinalIgnoreCase))?.Value?.Trim();

    private static string ResolveId(XElement el) =>
        (string?)el.Attribute("id") ??
        (string?)el.Attribute("name") ??
        $"{el.Name.LocalName}_{Guid.NewGuid():N}";

    private static string? FindDescValue(XElement el, string localName) =>
        el.Descendants().FirstOrDefault(x => x.Name.LocalName.Equals(localName, StringComparison.OrdinalIgnoreCase))?.Value?.Trim();

    private static string? InferProtocol(string? type)
    {
        if (string.IsNullOrWhiteSpace(type)) return null;
        if (type.Contains("http", StringComparison.OrdinalIgnoreCase)) return "http";
        if (type.Contains("jms", StringComparison.OrdinalIgnoreCase)) return "jms";
        if (type.Contains("file", StringComparison.OrdinalIgnoreCase)) return "file";
        if (type.Contains("soap", StringComparison.OrdinalIgnoreCase)) return "soap";
        return null;
    }

    private static bool LooksLikeXPath(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return false;
        var v = value.Trim();
        return v.StartsWith("/") || v.StartsWith("$") || v.Contains("xpath", StringComparison.OrdinalIgnoreCase) || v.Contains("/processData/");
    }

    private static string? NormalizePossibleXPath(string? value) => LooksLikeXPath(value) ? value?.Trim() : null;
}
