using BwParser.Bpmn2;
using BwParser.Core;
using System.Text.Json;

var filePath = @".\Test.xml";
if (!File.Exists(filePath))
{
    Console.Error.WriteLine($"File not found: {filePath}");
    return 2;
}

var reader = new BwXmlReader();
var raw = reader.Read(filePath);
var builder = new BwAstBuilder();
var ast = builder.Build(raw);
var graph = builder.BuildGraph(ast);

var payload = new
{
    ast.Name,
    ast.XmlNamespace,
    Nodes = ast.Nodes.Select(n => new
    {
        n.Id,
        n.Name,
        Kind = n.Kind.ToString(),
        n.BwType,
        n.Metadata,
        Trigger = n is BwStarterNode s ? s.Trigger : null,
        CalledProcess = n is BwSubprocessCallNode sp ? sp.CalledProcess : null,
        IsSynchronous = n is BwSubprocessCallNode sp2 ? sp2.IsSynchronous : (bool?)null
    }),
    Transitions = ast.Transitions,
    Graph = new
    {
        graph.ProcessName,
        Outgoing = graph.Outgoing.ToDictionary(k => k.Key, v => v.Value.Select(e => e.To).ToList()),
        Incoming = graph.Incoming.ToDictionary(k => k.Key, v => v.Value.Select(e => e.From).ToList())
    }
};
/*
Console.WriteLine(JsonSerializer.Serialize(payload, new JsonSerializerOptions
{
    WriteIndented = true
}));
*/


var mapper = new BwToBpmnMapper();
var bpmnDefinitions = mapper.Map(ast);

// soit s�rialiser en JSON pour inspection
var bpmnJson = JsonSerializer.Serialize(bpmnDefinitions, new JsonSerializerOptions { WriteIndented = true });
Console.WriteLine(bpmnJson);

// soit g�n�rer un XML BPMN2
var xml = BpmnXmlSerializer.Serialize(bpmnDefinitions);
File.WriteAllText("output.bpmn", xml);

return 0;
