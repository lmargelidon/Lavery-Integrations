using System.Xml.Linq;

namespace BwParser.Core;

public sealed class BwXmlReader
{
    public RawBwProcess Read(string filePath)
    {
        var doc = XDocument.Load(filePath, LoadOptions.PreserveWhitespace | LoadOptions.SetLineInfo);
        var root = doc.Root ?? throw new InvalidOperationException("Missing XML root.");

        var processName = (string?)root.Attribute("name") ?? Path.GetFileNameWithoutExtension(filePath);
        var nodeElements = new List<RawBwElement>();
        var transitionElements = new List<RawBwElement>();

        // On parcourt tous les descendants, pas seulement les enfants directs
        foreach (var el in root.Descendants())
        {
            var local = el.Name.LocalName;

            if (IsNodeElement(local))
            {
                nodeElements.Add(new RawBwElement
                {
                    ElementName = local,
                    Id = ResolveId(el),
                    Name = (string?)el.Attribute("name") ?? ResolveId(el),
                    Element = el
                });
            }
            else if (IsTransitionElement(local))
            {
                transitionElements.Add(new RawBwElement
                {
                    ElementName = local,
                    Id = ResolveId(el),
                    Name = (string?)el.Attribute("name") ?? ResolveId(el),
                    Element = el
                });
            }
        }

        return new RawBwProcess
        {
            Name = processName,
            XmlNamespace = root.Name.NamespaceName,
            Attributes = root.Attributes().ToDictionary(a => a.Name.LocalName, a => a.Value),
            NodeElements = nodeElements,
            TransitionElements = transitionElements
        };
    }

    // Reconna�t plus de formes de n�uds BW proches de ton exemple (starter, activity, subprocess, gateways, events)
    private static bool IsNodeElement(string localName) =>
        localName.Equals("starter", StringComparison.OrdinalIgnoreCase) ||
        localName.Equals("activity", StringComparison.OrdinalIgnoreCase) ||
        localName.Equals("subprocess", StringComparison.OrdinalIgnoreCase) ||
        localName.Equals("startevent", StringComparison.OrdinalIgnoreCase) ||
        localName.Equals("endevent", StringComparison.OrdinalIgnoreCase) ||
        localName.Equals("gateway", StringComparison.OrdinalIgnoreCase) ||
        localName.Equals("event", StringComparison.OrdinalIgnoreCase);

    private static bool IsTransitionElement(string localName) =>
        localName.Equals("transition", StringComparison.OrdinalIgnoreCase) ||
        localName.Equals("sequenceflow", StringComparison.OrdinalIgnoreCase);

    private static string ResolveId(XElement el) =>
        (string?)el.Attribute("id") ??
        (string?)el.Attribute("name") ??
        $"{el.Name.LocalName}_{Guid.NewGuid():N}";
}