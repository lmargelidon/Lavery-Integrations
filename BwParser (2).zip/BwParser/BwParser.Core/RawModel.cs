using System.Xml.Linq;

namespace BwParser.Core;

public sealed class RawBwProcess
{
    public string Name { get; init; } = "";
    public string? XmlNamespace { get; init; }
    public Dictionary<string, string> Attributes { get; init; } = new();
    public List<RawBwElement> NodeElements { get; init; } = new();
    public List<RawBwElement> TransitionElements { get; init; } = new();
}

public sealed class RawBwElement
{
    public string ElementName { get; init; } = "";
    public string Id { get; init; } = "";
    public string Name { get; init; } = "";
    public XElement Element { get; init; } = default!;
}
