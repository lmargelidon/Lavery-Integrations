namespace BwParser.Core;

public sealed class BwProcessAst
{
    public string Name { get; init; } = "";
    public string? XmlNamespace { get; init; }
    public Dictionary<string, string> Attributes { get; init; } = new();
    public List<BwNode> Nodes { get; init; } = new();
    public List<BwTransition> Transitions { get; init; } = new();
    public Dictionary<string, BwNode> NodeById => Nodes.ToDictionary(n => n.Id, StringComparer.OrdinalIgnoreCase);
}

public abstract class BwNode
{
    public string Id { get; init; } = "";
    public string Name { get; init; } = "";
    public BwNodeKind Kind { get; init; }
    public string? BwType { get; init; }
    public Dictionary<string, string> Attributes { get; init; } = new();
    public List<BwPort> Inputs { get; init; } = new();
    public List<BwPort> Outputs { get; init; } = new();
    public BwMetadata Metadata { get; init; } = new();
}

public enum BwNodeKind
{
    Starter,
    Activity,
    SubprocessCall,
    Gateway,
    Event,
    Group,
    Unknown
}
public sealed class BwStarterNode : BwNode
{
    public BwStarterTrigger Trigger { get; init; } = new();
}

public sealed class BwActivityNode : BwNode
{
}

public sealed class BwSubprocessCallNode : BwNode
{
    public string? CalledProcess { get; init; }
    public bool IsSynchronous { get; init; }
}

public sealed class BwTransition
{
    public string Id { get; init; } = "";
    public string From { get; init; } = "";
    public string To { get; init; } = "";
    public string? ConditionType { get; init; }
    public string? ConditionExpression { get; init; }
    public bool IsDefault { get; init; }
    public Dictionary<string, string> Attributes { get; init; } = new();
}

public sealed class BwPort
{
    public string Name { get; init; } = "";
    public string? SchemaRef { get; init; }
    public string? XPath { get; init; }
    public string? Direction { get; init; }
}

public sealed class BwStarterTrigger
{
    public string? Protocol { get; init; }
    public string? Method { get; init; }
    public string? Path { get; init; }
    public string? Destination { get; init; }
    public string? EventName { get; init; }
}

public sealed class BwMetadata
{
    public string? Endpoint { get; init; }
    public string? Operation { get; init; }
    public string? AdapterService { get; init; }
    public string? JdbcStatement { get; init; }
    public string? XsltRef { get; init; }
    public List<string> XPaths { get; init; } = new();
    public Dictionary<string, string> RawProperties { get; init; } = new();
}

public sealed class BwControlFlowGraph
{
    public string ProcessName { get; init; } = "";
    public List<BwNode> Vertices { get; init; } = new();
    public List<BwTransition> Edges { get; init; } = new();
    public Dictionary<string, List<BwTransition>> Outgoing { get; init; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, List<BwTransition>> Incoming { get; init; } = new(StringComparer.OrdinalIgnoreCase);
}
