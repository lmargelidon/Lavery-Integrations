using System.Xml.Linq;

namespace BwParser.Bpmn2;

public static class BpmnXmlSerializer
{
    private static readonly XNamespace BpmnNs = "http://www.omg.org/spec/BPMN/20100524/MODEL";
    private static readonly XNamespace BpmndiNs = "http://www.omg.org/spec/BPMN/20100524/DI";
    private static readonly XNamespace DcNs = "http://www.omg.org/spec/DD/20100524/DC";
    private static readonly XNamespace DiNs = "http://www.omg.org/spec/DD/20100524/DI";
    private static readonly XNamespace XsiNs = "http://www.w3.org/2001/XMLSchema-instance";
    private static readonly XNamespace ExtNs = "urn:bwparser:bpmn2:extensions";

    public static string Serialize(BpmnDefinitions definitions)
    {
        var root = new XElement(BpmnNs + "definitions",
            new XAttribute(XNamespace.Xmlns + "bpmn", BpmnNs),
            new XAttribute(XNamespace.Xmlns + "bpmndi", BpmndiNs),
            new XAttribute(XNamespace.Xmlns + "dc", DcNs),
            new XAttribute(XNamespace.Xmlns + "di", DiNs),
            new XAttribute(XNamespace.Xmlns + "xsi", XsiNs),
            new XAttribute(XNamespace.Xmlns + "ext", ExtNs),
            new XAttribute("id", definitions.Id),
            new XAttribute("targetNamespace", definitions.TargetNamespace));

        foreach (var process in definitions.Processes)
            root.Add(SerializeProcess(process));

        foreach (var process in definitions.Processes)
            root.Add(SerializeDiagram(process));

        var doc = new XDocument(new XDeclaration("1.0", "utf-8", "yes"), root);
        return doc.ToString();
    }

    private static XElement SerializeProcess(BpmnProcess process)
    {
        var el = new XElement(BpmnNs + "process",
            new XAttribute("id", process.Id),
            new XAttribute("isExecutable", process.IsExecutable.ToString().ToLowerInvariant()));

        if (!string.IsNullOrWhiteSpace(process.Name))
            el.Add(new XAttribute("name", process.Name));

        foreach (var node in process.FlowNodes)
            el.Add(SerializeFlowNode(node));

        foreach (var flow in process.SequenceFlows)
            el.Add(SerializeSequenceFlow(flow));

        return el;
    }

    private static XElement SerializeFlowNode(BpmnFlowNode node)
    {
        var el = node switch
        {
            BpmnStartEvent s => SerializeStartEvent(s),
            BpmnEndEvent e => SerializeEndEvent(e),
            BpmnIntermediateCatchEvent i => SerializeIntermediateCatchEvent(i),
            BpmnCallActivity c => SerializeCallActivity(c),
            BpmnSubProcess sp => SerializeSubProcess(sp),
            BpmnGateway g => SerializeGateway(g),
            BpmnTask t => SerializeTask(t),
            _ => SerializeGenericNode("task", node)
        };

        AppendIncomingOutgoing(node, el);
        AppendExtensions(node.Extensions, el);
        return el;
    }

    private static XElement SerializeStartEvent(BpmnStartEvent node)
    {
        var el = SerializeGenericNode("startEvent", node);
        AppendEventDefinition(node.EventDefinitionType, el);
        return el;
    }

    private static XElement SerializeEndEvent(BpmnEndEvent node)
    {
        var el = SerializeGenericNode("endEvent", node);
        AppendEventDefinition(node.EventDefinitionType, el);
        return el;
    }

    private static XElement SerializeIntermediateCatchEvent(BpmnIntermediateCatchEvent node)
    {
        var el = SerializeGenericNode("intermediateCatchEvent", node);
        AppendEventDefinition(node.EventDefinitionType, el);
        return el;
    }

    private static XElement SerializeTask(BpmnTask node)
    {
        var elementName = node.TaskType switch
        {
            "serviceTask" => "serviceTask",
            "scriptTask" => "scriptTask",
            "userTask" => "userTask",
            "manualTask" => "manualTask",
            "receiveTask" => "receiveTask",
            "sendTask" => "sendTask",
            "businessRuleTask" => "businessRuleTask",
            _ => "task"
        };

        return SerializeGenericNode(elementName, node);
    }

    private static XElement SerializeGateway(BpmnGateway node)
    {
        var elementName = node.GatewayType switch
        {
            "parallelGateway" => "parallelGateway",
            "inclusiveGateway" => "inclusiveGateway",
            "eventBasedGateway" => "eventBasedGateway",
            _ => "exclusiveGateway"
        };

        var el = SerializeGenericNode(elementName, node);

        if (!string.IsNullOrWhiteSpace(node.GatewayDirection) &&
            !string.Equals(node.GatewayDirection, "Unspecified", StringComparison.OrdinalIgnoreCase))
        {
            el.Add(new XAttribute("gatewayDirection", node.GatewayDirection));
        }

        if (!string.IsNullOrWhiteSpace(node.DefaultFlowId) &&
            (elementName == "exclusiveGateway" || elementName == "inclusiveGateway"))
        {
            el.Add(new XAttribute("default", node.DefaultFlowId));
        }

        return el;
    }

    private static XElement SerializeCallActivity(BpmnCallActivity node)
    {
        var el = SerializeGenericNode("callActivity", node);
        if (!string.IsNullOrWhiteSpace(node.CalledElement))
            el.Add(new XAttribute("calledElement", node.CalledElement));
        return el;
    }

    private static XElement SerializeSubProcess(BpmnSubProcess node)
    {
        var el = SerializeGenericNode("subProcess", node);
        if (node.TriggeredByEvent)
            el.Add(new XAttribute("triggeredByEvent", "true"));

        foreach (var child in node.FlowNodes)
            el.Add(SerializeFlowNode(child));

        foreach (var flow in node.SequenceFlows)
            el.Add(SerializeSequenceFlow(flow));

        return el;
    }

    private static XElement SerializeSequenceFlow(BpmnSequenceFlow flow)
    {
        var el = new XElement(BpmnNs + "sequenceFlow",
            new XAttribute("id", flow.Id),
            new XAttribute("sourceRef", flow.SourceRef),
            new XAttribute("targetRef", flow.TargetRef));

        if (!string.IsNullOrWhiteSpace(flow.Name))
            el.Add(new XAttribute("name", flow.Name));

        if (!string.IsNullOrWhiteSpace(flow.ConditionExpression))
        {
            el.Add(new XElement(BpmnNs + "conditionExpression",
                new XAttribute(XsiNs + "type", "bpmn:tFormalExpression"),
                new XCData(flow.ConditionExpression)));
        }

        AppendExtensions(flow.Extensions, el);
        return el;
    }

    private static XElement SerializeGenericNode(string localName, BpmnBaseElement node)
    {
        var el = new XElement(BpmnNs + localName, new XAttribute("id", node.Id));
        if (!string.IsNullOrWhiteSpace(node.Name))
            el.Add(new XAttribute("name", node.Name));
        return el;
    }

    private static void AppendIncomingOutgoing(BpmnFlowNode node, XElement el)
    {
        foreach (var incoming in node.Incoming)
            el.Add(new XElement(BpmnNs + "incoming", incoming));

        foreach (var outgoing in node.Outgoing)
            el.Add(new XElement(BpmnNs + "outgoing", outgoing));
    }

    private static void AppendExtensions(Dictionary<string, string> extensions, XElement el)
    {
        if (extensions.Count == 0) return;

        var ext = new XElement(BpmnNs + "extensionElements");

        foreach (var kv in extensions.OrderBy(k => k.Key, StringComparer.OrdinalIgnoreCase))
        {
            ext.Add(new XElement(ExtNs + "property",
                new XAttribute("name", kv.Key),
                new XAttribute("value", kv.Value ?? string.Empty)));
        }

        el.Add(ext);
    }

    private static void AppendEventDefinition(string? kind, XElement el)
    {
        if (string.IsNullOrWhiteSpace(kind)) return;

        var child = kind.ToLowerInvariant() switch
        {
            "message" => new XElement(BpmnNs + "messageEventDefinition"),
            "timer" => new XElement(BpmnNs + "timerEventDefinition"),
            "signal" => new XElement(BpmnNs + "signalEventDefinition"),
            "error" => new XElement(BpmnNs + "errorEventDefinition"),
            "terminate" => new XElement(BpmnNs + "terminateEventDefinition"),
            _ => null
        };

        if (child is not null)
            el.Add(child);
    }

    private static XElement SerializeDiagram(BpmnProcess process)
    {
        var layout = BuildLayout(process);

        var plane = new XElement(BpmndiNs + "BPMNPlane",
            new XAttribute("id", $"BPMNPlane_{process.Id}"),
            new XAttribute("bpmnElement", process.Id));

        foreach (var node in process.FlowNodes)
        {
            var (x, y, w, h) = layout[node.Id];

            var shape = new XElement(BpmndiNs + "BPMNShape",
                new XAttribute("id", $"Shape_{node.Id}"),
                new XAttribute("bpmnElement", node.Id),
                new XElement(DcNs + "Bounds",
                    new XAttribute("x", x),
                    new XAttribute("y", y),
                    new XAttribute("width", w),
                    new XAttribute("height", h)));

            if (node is BpmnSubProcess)
                shape.Add(new XAttribute("isExpanded", "true"));

            plane.Add(shape);
        }

        foreach (var flow in process.SequenceFlows)
        {
            if (!layout.TryGetValue(flow.SourceRef, out var s) || !layout.TryGetValue(flow.TargetRef, out var t))
                continue;

            var sourcePoint = GetEdgeStart(s);
            var targetPoint = GetEdgeEnd(t);

            var edge = new XElement(BpmndiNs + "BPMNEdge",
                new XAttribute("id", $"Edge_{flow.Id}"),
                new XAttribute("bpmnElement", flow.Id),
                new XElement(DiNs + "waypoint",
                    new XAttribute("x", sourcePoint.x),
                    new XAttribute("y", sourcePoint.y)),
                new XElement(DiNs + "waypoint",
                    new XAttribute("x", targetPoint.x),
                    new XAttribute("y", targetPoint.y)));

            plane.Add(edge);
        }

        return new XElement(BpmndiNs + "BPMNDiagram",
            new XAttribute("id", $"BPMNDiagram_{process.Id}"),
            plane);
    }

    private static Dictionary<string, (double x, double y, double w, double h)> BuildLayout(BpmnProcess process)
    {
        var result = new Dictionary<string, (double x, double y, double w, double h)>(StringComparer.OrdinalIgnoreCase);

        const double startX = 120;
        const double startY = 160;
        const double horizontalSpacing = 180;
        const double verticalSpacing = 140;

        var incomingCount = process.FlowNodes.ToDictionary(n => n.Id, n => n.Incoming.Count, StringComparer.OrdinalIgnoreCase);
        var queue = new Queue<string>();
        var depthByNode = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        var laneByNode = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        var startNodes = process.FlowNodes.Where(n => n.Incoming.Count == 0).ToList();
        if (startNodes.Count == 0 && process.FlowNodes.Count > 0)
            startNodes.Add(process.FlowNodes[0]);

        for (int i = 0; i < startNodes.Count; i++)
        {
            var n = startNodes[i];
            queue.Enqueue(n.Id);
            depthByNode[n.Id] = 0;
            laneByNode[n.Id] = i;
        }

        var outgoingMap = process.SequenceFlows
            .GroupBy(f => f.SourceRef, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.Select(f => f.TargetRef).ToList(), StringComparer.OrdinalIgnoreCase);

        while (queue.Count > 0)
        {
            var current = queue.Dequeue();
            var currentDepth = depthByNode[current];
            var currentLane = laneByNode[current];

            if (!outgoingMap.TryGetValue(current, out var targets))
                continue;

            for (int i = 0; i < targets.Count; i++)
            {
                var target = targets[i];
                if (!depthByNode.ContainsKey(target))
                {
                    depthByNode[target] = currentDepth + 1;
                    laneByNode[target] = currentLane + i;
                    queue.Enqueue(target);
                }
            }
        }

        var assigned = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var node in process.FlowNodes)
        {
            if (!depthByNode.ContainsKey(node.Id))
                depthByNode[node.Id] = depthByNode.Count;
            if (!laneByNode.ContainsKey(node.Id))
                laneByNode[node.Id] = assigned.Count;

            var (w, h) = GetNodeSize(node);
            var x = startX + (depthByNode[node.Id] * horizontalSpacing);
            var y = startY + (laneByNode[node.Id] * verticalSpacing);
            result[node.Id] = (x, y, w, h);
            assigned.Add(node.Id);
        }

        return result;
    }

    private static (double x, double y) GetEdgeStart((double x, double y, double w, double h) rect)
        => (rect.x + rect.w, rect.y + rect.h / 2.0);

    private static (double x, double y) GetEdgeEnd((double x, double y, double w, double h) rect)
        => (rect.x, rect.y + rect.h / 2.0);

    private static (double w, double h) GetNodeSize(BpmnFlowNode node) =>
        node switch
        {
            BpmnStartEvent => (36, 36),
            BpmnEndEvent => (36, 36),
            BpmnIntermediateCatchEvent => (36, 36),
            BpmnGateway => (50, 50),
            BpmnCallActivity => (120, 80),
            BpmnSubProcess => (140, 100),
            _ => (110, 80)
        };
}
