﻿using BwParser.Core;
using BwParser.Bpmn2;

namespace BwParser.Bridge;

public sealed class Bpmn2AstBuilder
{
    /*
    public BpmnDefinitions Build(BwProcessAst bw)
    {
        var defs = new BpmnDefinitions
        {
            Id = $"Defs_{SanitizeId(bw.Name)}",
            TargetNamespace = bw.XmlNamespace ?? "http://example.org/bpmn"
        };

        var process = new BpmnProcess
        {
            Id = $"Process_{SanitizeId(bw.Name)}",
            Name = bw.Name
        };

        // Map nœuds
        var nodeMap = new Dictionary<string, BpmnFlowNode>(StringComparer.OrdinalIgnoreCase);

        foreach (var node in bw.Nodes)
        {
            var bpmnNode = MapNode(node);
            process.FlowNodes.Add(bpmnNode);
            nodeMap[node.Id] = bpmnNode;
        }

        // Map transitions vers sequenceFlow
        foreach (var t in bw.Transitions)
        {
            // On ne garde que les flows entre nœuds connus, comme BwAstBuilder
            if (!nodeMap.ContainsKey(t.From) || !nodeMap.ContainsKey(t.To))
                continue;

            var flow = new BpmnSequenceFlow
            {
                Id = string.IsNullOrEmpty(t.Id) ? $"Flow_{SanitizeId(t.From)}_{SanitizeId(t.To)}" : t.Id,
                SourceRef = nodeMap[t.From].Id,
                TargetRef = nodeMap[t.To].Id,
                ConditionExpression = t.ConditionExpression,
                IsDefault = t.IsDefault
            };

            process.SequenceFlows.Add(flow);
        }

        defs.Processes.Add(process);
        return defs;
    }

    private static string SanitizeId(string raw) =>
        new string(raw.Where(char.IsLetterOrDigit).ToArray());
        */
}