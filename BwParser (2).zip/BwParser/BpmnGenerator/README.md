# BwParser.Bpmn2

Projet séparé pour la couche BPMN2. Il dépend de `BwParser.Core` et fournit :

- un modèle BPMN2 intermédiaire riche (`BpmnDefinitions`, `BpmnProcess`, `BpmnTask`, `BpmnGateway`, etc.) ;
- un mapper `BwToBpmnMapper` pour traduire l'AST BW (`BwProcessAst`) vers un modèle BPMN2 ;
- un sérialiseur XML `BpmnXmlSerializer` qui génère un fichier `.bpmn` au format OMG BPMN 2.0.

## Structure

- `BpmnModel.cs` : DTO BPMN2 internes.
- `BwToBpmnMapper.cs` : mapping BW -> BPMN.
- `BpmnXmlSerializer.cs` : génération XML BPMN2.
- `BwParser.Bpmn2.csproj` : projet .NET séparé référencant `BwParser.Core`.

## Mapping couvert

### Nœuds BW -> BPMN

- `BwStarterNode` -> `bpmn:startEvent`
- `BwSubprocessCallNode` -> `bpmn:callActivity`
- `BwNode` type gateway / décision -> `bpmn:exclusiveGateway`, `parallelGateway`, `inclusiveGateway`, `eventBasedGateway`
- nœud fin / stop / terminate -> `bpmn:endEvent`
- nœud intermédiaire timer / message / wait -> `bpmn:intermediateCatchEvent`
- autres activités -> `bpmn:task`, `serviceTask`, `scriptTask`, `userTask`, etc.

### Transitions BW -> BPMN

- `BwTransition` -> `bpmn:sequenceFlow`
- `ConditionExpression` -> `bpmn:conditionExpression`
- `IsDefault` -> affecté au gateway via l'attribut BPMN `default`

### Préservation de l'information BW

Les attributs et métadonnées BW sont copiés en `bpmn:extensionElements` sous la forme :

- `ext:property name="bw.attr.*"`
- `ext:property name="bw.meta.*"`
- `ext:property name="bw.input.*"`
- `ext:property name="bw.output.*"`
- `ext:property name="bw.trigger.*"`

## Utilisation

```csharp
using BwParser.Core;
using BwParser.Bpmn2;

var reader = new BwXmlReader();
var raw = reader.Read("Test.bw");
var bwBuilder = new BwAstBuilder();
var bwAst = bwBuilder.Build(raw);

var mapper = new BwToBpmnMapper();
var defs = mapper.Map(bwAst);

var xml = BpmnXmlSerializer.Serialize(defs);
File.WriteAllText("output.bpmn", xml);
```

## Exemple d'intégration dans ton projet console

```csharp
using System.Text.Json;
using BwParser.Core;
using BwParser.Bpmn2;

var filePath = args.Length > 0 ? args[0] : @"./Test.bw";
if (!File.Exists(filePath))
{
    Console.Error.WriteLine($"File not found: {filePath}");
    return 2;
}

var reader = new BwXmlReader();
var raw = reader.Read(filePath);
var bwBuilder = new BwAstBuilder();
var bwAst = bwBuilder.Build(raw);

var mapper = new BwToBpmnMapper();
var defs = mapper.Map(bwAst);
var bpmnXml = BpmnXmlSerializer.Serialize(defs);
File.WriteAllText("output.bpmn", bpmnXml);

Console.WriteLine(JsonSerializer.Serialize(new
{
    bwAst.Name,
    NodeCount = bwAst.Nodes.Count,
    TransitionCount = bwAst.Transitions.Count,
    BpmnProcessId = defs.Processes[0].Id,
    BpmnNodeCount = defs.Processes[0].FlowNodes.Count,
    BpmnFlowCount = defs.Processes[0].SequenceFlows.Count
}, new JsonSerializerOptions { WriteIndented = true }));

return 0;
```

## Notes de conception

- Le mapper est volontairement **exhaustif mais tolérant** : il utilise `BwNodeKind`, `BwType`, le nom du nœud et les métadonnées pour inférer le type BPMN le plus probable.
- Si aucun start/end n'est détecté, le mapper ajoute automatiquement un `StartEvent_Auto` et/ou un `EndEvent_Auto` pour produire un processus BPMN structurellement exploitable.
- Le serializer produit un XML BPMN2 compatible outillage, avec namespaces OMG et `xsi:type="bpmn:tFormalExpression"` sur les conditions.
- Les informations BW non représentables nativement en BPMN sont conservées dans `extensionElements`.
