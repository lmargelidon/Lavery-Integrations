namespace BwParser.Bpmn2;

public sealed class BpmnDefinitions
{
    public string Id { get; init; } = "Definitions_1";
    public string TargetNamespace { get; init; } = "http://example.org/bpmn";
    public List<BpmnProcess> Processes { get; init; } = new();
}

public sealed class BpmnProcess
{
    public string Id { get; init; } = string.Empty;
    public string Name { get; init; } = string.Empty;
    public bool IsExecutable { get; init; }
    public List<BpmnFlowNode> FlowNodes { get; init; } = new();
    public List<BpmnSequenceFlow> SequenceFlows { get; init; } = new();
}

public abstract class BpmnBaseElement
{
    public string Id { get; init; } = string.Empty;
    public string? Name { get; init; }
    public Dictionary<string, string> Extensions { get; init; } = new(StringComparer.OrdinalIgnoreCase);
}

public abstract class BpmnFlowNode : BpmnBaseElement
{
    public List<string> Incoming { get; init; } = new();
    public List<string> Outgoing { get; init; } = new();
}

public sealed class BpmnStartEvent : BpmnFlowNode
{
    public string? EventDefinitionType { get; init; }
}

public sealed class BpmnEndEvent : BpmnFlowNode
{
    public string? EventDefinitionType { get; init; }
}

public sealed class BpmnIntermediateCatchEvent : BpmnFlowNode
{
    public string? EventDefinitionType { get; init; }
}

public sealed class BpmnTask : BpmnFlowNode
{
    public string TaskType { get; init; } = "task";
}

public sealed class BpmnSubProcess : BpmnFlowNode
{
    public bool TriggeredByEvent { get; init; }
    public List<BpmnFlowNode> FlowNodes { get; init; } = new();
    public List<BpmnSequenceFlow> SequenceFlows { get; init; } = new();
}

public sealed class BpmnCallActivity : BpmnFlowNode
{
    public string? CalledElement { get; init; }
    public bool IsSynchronous { get; init; }
}

public sealed class BpmnGateway : BpmnFlowNode
{
    public string GatewayType { get; init; } = "exclusiveGateway";
    public string GatewayDirection { get; set; } = "Unspecified";
    public string? DefaultFlowId { get; set; }
}

public sealed class BpmnSequenceFlow : BpmnBaseElement
{
    public string SourceRef { get; init; } = string.Empty;
    public string TargetRef { get; init; } = string.Empty;
    public string? ConditionExpression { get; init; }
    public bool IsDefault { get; init; }
}
