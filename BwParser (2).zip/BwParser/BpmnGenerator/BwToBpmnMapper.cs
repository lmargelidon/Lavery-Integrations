using BwParser.Core;

namespace BwParser.Bpmn2;

public sealed class BwToBpmnMapper
{
    public BpmnDefinitions Map(BwProcessAst bw)
    {
        var process = new BpmnProcess
        {
            Id = ToProcessId(bw.Name),
            Name = bw.Name,
            IsExecutable = false
        };

        var nodeMap = new Dictionary<string, BpmnFlowNode>(StringComparer.OrdinalIgnoreCase);

        foreach (var bwNode in bw.Nodes)
        {
            var mapped = MapNode(bwNode);
            process.FlowNodes.Add(mapped);
            nodeMap[bwNode.Id] = mapped;
        }

        foreach (var edge in bw.Transitions)
        {
            if (!nodeMap.TryGetValue(edge.From, out var source) || !nodeMap.TryGetValue(edge.To, out var target))
                continue;

            var flow = new BpmnSequenceFlow
            {
                Id = string.IsNullOrWhiteSpace(edge.Id) ? $"Flow_{Sanitize(edge.From)}_{Sanitize(edge.To)}" : edge.Id,
                Name = edge.ConditionExpression,
                SourceRef = source.Id,
                TargetRef = target.Id,
                ConditionExpression = edge.ConditionExpression,
                IsDefault = edge.IsDefault,
                Extensions = CopyExtensions(edge.Attributes)
            };

            process.SequenceFlows.Add(flow);
            source.Outgoing.Add(flow.Id);
            target.Incoming.Add(flow.Id);
        }

        ApplyGatewaySemantics(process);
        EnsureBoundaryShape(process);

        return new BpmnDefinitions
        {
            Id = $"Definitions_{Sanitize(bw.Name)}",
            TargetNamespace = string.IsNullOrWhiteSpace(bw.XmlNamespace) ? "http://example.org/bpmn" : bw.XmlNamespace!,
            Processes = { process }
        };
    }

    private static void EnsureBoundaryShape(BpmnProcess process)
    {
        var hasStart = process.FlowNodes.OfType<BpmnStartEvent>().Any();
        var hasEnd = process.FlowNodes.OfType<BpmnEndEvent>().Any();

        if (!hasStart)
        {
            var start = new BpmnStartEvent { Id = "StartEvent_Auto", Name = "Start" };
            process.FlowNodes.Insert(0, start);
            var first = process.FlowNodes.FirstOrDefault(n => n.Id != start.Id);
            if (first is not null)
            {
                var flow = new BpmnSequenceFlow
                {
                    Id = $"Flow_{start.Id}_{first.Id}",
                    SourceRef = start.Id,
                    TargetRef = first.Id
                };
                process.SequenceFlows.Insert(0, flow);
                start.Outgoing.Add(flow.Id);
                first.Incoming.Add(flow.Id);
            }
        }

        if (!hasEnd)
        {
            var end = new BpmnEndEvent { Id = "EndEvent_Auto", Name = "End" };
            process.FlowNodes.Add(end);
            var terminalNodes = process.FlowNodes
                .Where(n => n.Id != end.Id && n.Outgoing.Count == 0)
                .ToList();

            foreach (var terminal in terminalNodes)
            {
                var flow = new BpmnSequenceFlow
                {
                    Id = $"Flow_{terminal.Id}_{end.Id}",
                    SourceRef = terminal.Id,
                    TargetRef = end.Id
                };
                process.SequenceFlows.Add(flow);
                terminal.Outgoing.Add(flow.Id);
                end.Incoming.Add(flow.Id);
            }
        }
    }

    private static void ApplyGatewaySemantics(BpmnProcess process)
    {
        var flowById = process.SequenceFlows.ToDictionary(f => f.Id, StringComparer.OrdinalIgnoreCase);

        foreach (var gw in process.FlowNodes.OfType<BpmnGateway>())
        {
            gw.GatewayDirection = gw.Incoming.Count switch
            {
                0 when gw.Outgoing.Count > 1 => "Diverging",
                1 when gw.Outgoing.Count > 1 => "Diverging",
                > 1 when gw.Outgoing.Count <= 1 => "Converging",
                > 1 when gw.Outgoing.Count > 1 => "Mixed",
                _ => "Unspecified"
            };

            var defaultFlow = gw.Outgoing
                .Select(id => flowById.GetValueOrDefault(id))
                .FirstOrDefault(f => f?.IsDefault == true);

            if (defaultFlow is not null)
                gw.DefaultFlowId = defaultFlow.Id;
        }
    }

    private BpmnFlowNode MapNode(BwNode node)
    {
        if (node is BwStarterNode starter)
            return MapStarter(starter);

        if (node is BwSubprocessCallNode call)
            return new BpmnCallActivity
            {
                Id = node.Id,
                Name = node.Name,
                CalledElement = call.CalledProcess,
                IsSynchronous = call.IsSynchronous,
                Extensions = CollectExtensions(node)
            };

        if (node.Kind == BwNodeKind.Gateway || LooksLikeGateway(node))
        {
            return new BpmnGateway
            {
                Id = node.Id,
                Name = node.Name,
                GatewayType = InferGatewayType(node),
                Extensions = CollectExtensions(node)
            };
        }

        if (IsEndLike(node))
        {
            return new BpmnEndEvent
            {
                Id = node.Id,
                Name = node.Name,
                EventDefinitionType = InferEventDefinition(node),
                Extensions = CollectExtensions(node)
            };
        }

        if (IsStartLike(node))
        {
            return new BpmnStartEvent
            {
                Id = node.Id,
                Name = node.Name,
                EventDefinitionType = InferEventDefinition(node),
                Extensions = CollectExtensions(node)
            };
        }

        if (IsIntermediateEvent(node))
        {
            return new BpmnIntermediateCatchEvent
            {
                Id = node.Id,
                Name = node.Name,
                EventDefinitionType = InferEventDefinition(node),
                Extensions = CollectExtensions(node)
            };
        }

        return new BpmnTask
        {
            Id = node.Id,
            Name = node.Name,
            TaskType = InferTaskType(node),
            Extensions = CollectExtensions(node)
        };
    }

    private static BpmnStartEvent MapStarter(BwStarterNode starter)
    {
        var evt = new BpmnStartEvent
        {
            Id = starter.Id,
            Name = starter.Name,
            EventDefinitionType = InferStartEventDefinition(starter),
            Extensions = CollectExtensions(starter)
        };
        return evt;
    }

    private static string InferTaskType(BwNode node)
    {
        var t = node.BwType ?? string.Empty;
        if (t.Contains("script", StringComparison.OrdinalIgnoreCase)) return "scriptTask";
        if (t.Contains("service", StringComparison.OrdinalIgnoreCase)) return "serviceTask";
        if (t.Contains("user", StringComparison.OrdinalIgnoreCase)) return "userTask";
        if (t.Contains("manual", StringComparison.OrdinalIgnoreCase)) return "manualTask";
        if (t.Contains("receive", StringComparison.OrdinalIgnoreCase)) return "receiveTask";
        if (t.Contains("send", StringComparison.OrdinalIgnoreCase)) return "sendTask";
        if (t.Contains("businessrule", StringComparison.OrdinalIgnoreCase)) return "businessRuleTask";
        if (!string.IsNullOrWhiteSpace(node.Metadata.AdapterService) || !string.IsNullOrWhiteSpace(node.Metadata.Endpoint)) return "serviceTask";
        return "task";
    }

    private static string InferGatewayType(BwNode node)
    {
        var text = string.Join(" ", new[] { node.BwType, node.Name }.Where(s => !string.IsNullOrWhiteSpace(s))!);
        if (text.Contains("parallel", StringComparison.OrdinalIgnoreCase)) return "parallelGateway";
        if (text.Contains("inclusive", StringComparison.OrdinalIgnoreCase)) return "inclusiveGateway";
        if (text.Contains("event", StringComparison.OrdinalIgnoreCase)) return "eventBasedGateway";
        return "exclusiveGateway";
    }

    private static bool LooksLikeGateway(BwNode node)
    {
        var text = string.Join(" ", new[] { node.BwType, node.Name }.Where(s => !string.IsNullOrWhiteSpace(s))!);
        return text.Contains("gateway", StringComparison.OrdinalIgnoreCase)
            || text.Contains("decision", StringComparison.OrdinalIgnoreCase)
            || text.Contains("route", StringComparison.OrdinalIgnoreCase)
            || text.Contains("branch", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsStartLike(BwNode node)
    {
        if (node is BwStarterNode) return true;
        var text = string.Join(" ", new[] { node.BwType, node.Name }.Where(s => !string.IsNullOrWhiteSpace(s))!);
        return text.Contains("start", StringComparison.OrdinalIgnoreCase)
            || text.Contains("receive", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsEndLike(BwNode node)
    {
        var text = string.Join(" ", new[] { node.BwType, node.Name }.Where(s => !string.IsNullOrWhiteSpace(s))!);
        return text.Contains("end", StringComparison.OrdinalIgnoreCase)
            || text.Contains("stop", StringComparison.OrdinalIgnoreCase)
            || text.Contains("terminate", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsIntermediateEvent(BwNode node)
    {
        var text = string.Join(" ", new[] { node.BwType, node.Name }.Where(s => !string.IsNullOrWhiteSpace(s))!);
        return text.Contains("intermediate", StringComparison.OrdinalIgnoreCase)
            || text.Contains("wait", StringComparison.OrdinalIgnoreCase)
            || text.Contains("timer", StringComparison.OrdinalIgnoreCase)
            || text.Contains("message", StringComparison.OrdinalIgnoreCase);
    }

    private static string? InferEventDefinition(BwNode node)
    {
        var text = string.Join(" ", new[]
        {
            node.BwType,
            node.Name,
            node.Metadata.Operation,
            node.Metadata.AdapterService,
            node.Metadata.Endpoint
        }.Where(s => !string.IsNullOrWhiteSpace(s))!);

        if (text.Contains("timer", StringComparison.OrdinalIgnoreCase)) return "timer";
        if (text.Contains("message", StringComparison.OrdinalIgnoreCase) || text.Contains("jms", StringComparison.OrdinalIgnoreCase) || text.Contains("http", StringComparison.OrdinalIgnoreCase)) return "message";
        if (text.Contains("signal", StringComparison.OrdinalIgnoreCase)) return "signal";
        if (text.Contains("error", StringComparison.OrdinalIgnoreCase)) return "error";
        if (text.Contains("terminate", StringComparison.OrdinalIgnoreCase)) return "terminate";
        return null;
    }

    private static string? InferStartEventDefinition(BwStarterNode node)
    {
        if (!string.IsNullOrWhiteSpace(node.Trigger.Protocol))
        {
            return node.Trigger.Protocol switch
            {
                "http" => "message",
                "jms" => "message",
                "soap" => "message",
                "file" => "signal",
                _ => null
            };
        }
        return InferEventDefinition(node);
    }

    private static Dictionary<string, string> CollectExtensions(BwNode node)
    {
        var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        foreach (var kv in node.Attributes)
            dict["bw.attr." + kv.Key] = kv.Value;

        foreach (var kv in node.Metadata.RawProperties)
            dict["bw.meta." + kv.Key] = kv.Value;

        if (!string.IsNullOrWhiteSpace(node.Metadata.Endpoint)) dict["bw.endpoint"] = node.Metadata.Endpoint!;
        if (!string.IsNullOrWhiteSpace(node.Metadata.Operation)) dict["bw.operation"] = node.Metadata.Operation!;
        if (!string.IsNullOrWhiteSpace(node.Metadata.AdapterService)) dict["bw.adapterService"] = node.Metadata.AdapterService!;
        if (!string.IsNullOrWhiteSpace(node.Metadata.JdbcStatement)) dict["bw.jdbcStatement"] = node.Metadata.JdbcStatement!;
        if (!string.IsNullOrWhiteSpace(node.Metadata.XsltRef)) dict["bw.xsltRef"] = node.Metadata.XsltRef!;

        for (var i = 0; i < node.Inputs.Count; i++)
        {
            var p = node.Inputs[i];
            dict[$"bw.input.{i}.name"] = p.Name;
            if (!string.IsNullOrWhiteSpace(p.SchemaRef)) dict[$"bw.input.{i}.schema"] = p.SchemaRef!;
            if (!string.IsNullOrWhiteSpace(p.XPath)) dict[$"bw.input.{i}.xpath"] = p.XPath!;
        }

        for (var i = 0; i < node.Outputs.Count; i++)
        {
            var p = node.Outputs[i];
            dict[$"bw.output.{i}.name"] = p.Name;
            if (!string.IsNullOrWhiteSpace(p.SchemaRef)) dict[$"bw.output.{i}.schema"] = p.SchemaRef!;
            if (!string.IsNullOrWhiteSpace(p.XPath)) dict[$"bw.output.{i}.xpath"] = p.XPath!;
        }

        if (node is BwStarterNode starter)
        {
            if (!string.IsNullOrWhiteSpace(starter.Trigger.Protocol)) dict["bw.trigger.protocol"] = starter.Trigger.Protocol!;
            if (!string.IsNullOrWhiteSpace(starter.Trigger.Method)) dict["bw.trigger.method"] = starter.Trigger.Method!;
            if (!string.IsNullOrWhiteSpace(starter.Trigger.Path)) dict["bw.trigger.path"] = starter.Trigger.Path!;
            if (!string.IsNullOrWhiteSpace(starter.Trigger.Destination)) dict["bw.trigger.destination"] = starter.Trigger.Destination!;
            if (!string.IsNullOrWhiteSpace(starter.Trigger.EventName)) dict["bw.trigger.event"] = starter.Trigger.EventName!;
        }

        if (node is BwSubprocessCallNode subprocess)
        {
            if (!string.IsNullOrWhiteSpace(subprocess.CalledProcess)) dict["bw.calledProcess"] = subprocess.CalledProcess!;
            dict["bw.isSynchronous"] = subprocess.IsSynchronous.ToString().ToLowerInvariant();
        }

        return dict;
    }

    private static Dictionary<string, string> CopyExtensions(Dictionary<string, string> source)
        => new(source, StringComparer.OrdinalIgnoreCase);

    private static string ToProcessId(string name) => $"Process_{Sanitize(name)}";

    private static string Sanitize(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return "X";
        var chars = raw.Select(c => char.IsLetterOrDigit(c) ? c : '_').ToArray();
        var text = new string(chars).Trim('_');
        return string.IsNullOrWhiteSpace(text) ? "X" : text;
    }
}
